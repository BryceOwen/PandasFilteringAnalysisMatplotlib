
# Assignment 4: Pandas

* Section: Sec01
    
* Name: Bryce Owen
    
* Due date:  29 February 2020
    
* Purpose:  Pandas data filtering and analysis with groupby, crosstab, pivot_table and matplot lib


```python
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
```


```python
wage = pd.read_csv('http://barney.gonzaga.edu/~chuang/data/wage.csv')
```


```python
wage.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>FirstName</th>
      <th>LastName</th>
      <th>MiddleName</th>
      <th>Sex</th>
      <th>Title</th>
      <th>Department</th>
      <th>BaseRate</th>
      <th>Hours</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Guy</td>
      <td>Gilbert</td>
      <td>R</td>
      <td>Male</td>
      <td>Production Technician - WC60</td>
      <td>Production</td>
      <td>12.45</td>
      <td>32</td>
    </tr>
    <tr>
      <th>1</th>
      <td>JoLynn</td>
      <td>Dobney</td>
      <td>M</td>
      <td>Female</td>
      <td>Production Supervisor - WC60</td>
      <td>Production</td>
      <td>25.00</td>
      <td>33</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Ruth</td>
      <td>Ellerbrock</td>
      <td>Ann</td>
      <td>Male</td>
      <td>Production Technician - WC10</td>
      <td>Production</td>
      <td>13.45</td>
      <td>35</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Barry</td>
      <td>Johnson</td>
      <td>K</td>
      <td>Male</td>
      <td>Production Technician - WC10</td>
      <td>Production</td>
      <td>13.45</td>
      <td>40</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Sidney</td>
      <td>Higa</td>
      <td>M</td>
      <td>Male</td>
      <td>Production Technician - WC10</td>
      <td>Production</td>
      <td>13.45</td>
      <td>45</td>
    </tr>
  </tbody>
</table>
</div>



## No groupby(), crosstab(), or pivot_table()


```python
#How many employees are in the Finance department?

wage[wage['Department'] == 'Finance'].count()[0]
```




    10




```python
# What is the mean of working hours of employees in the Production department?  

round(wage[wage['Department'] == 'Production']['Hours'].mean(),2)
```




    37.79




```python
# How many male employees are in the Sales department?

wage[(wage['Department'] == 'Sales') & (wage['Sex'] == 'Male')].count()[0]
```




    16




```python
# What is the mean of weekly wages of female employees in the Marketing department?

wage = wage.assign(WeeklyWages = wage['BaseRate'] * wage['Hours'])
round(wage[(wage['Department'] == 'Marketing') & (wage['Sex'] == 'Female')]['WeeklyWages'].mean(),2)
```




    496.8



## Groupby(), crosstab(), or pivot_table() allowed


```python
# What are the totals of weekly wages of female and male employees?

wage.groupby('Sex')[['WeeklyWages']].sum()    
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>WeeklyWages</th>
    </tr>
    <tr>
      <th>Sex</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Female</th>
      <td>36652.192</td>
    </tr>
    <tr>
      <th>Male</th>
      <td>168600.804</td>
    </tr>
  </tbody>
</table>
</div>




```python
# What are the numbers of male and female employees in the Marketing, Production, and Human Resources Departments? 

wage_MPHR = wage[(wage['Department'] == 'Marketing') | (wage['Department'] == 'Production') | (wage['Department'] == 'Human Resources')]
pd.crosstab(index = wage_MPHR['Department'], columns = wage_MPHR['Sex'], values = wage_MPHR['LastName'], aggfunc = 'count')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Sex</th>
      <th>Female</th>
      <th>Male</th>
    </tr>
    <tr>
      <th>Department</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Human Resources</th>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>Marketing</th>
      <td>3</td>
      <td>7</td>
    </tr>
    <tr>
      <th>Production</th>
      <td>31</td>
      <td>148</td>
    </tr>
  </tbody>
</table>
</div>




```python
# What are the means of weekly wages of the Marketing, Production and Engineering departments?

wage_MPE = wage[(wage['Department'] == 'Marketing') | (wage['Department'] == 'Production') | (wage['Department'] == 'Engineering')]
wage_MPE.pivot_table(index = 'Department', values = 'WeeklyWages', aggfunc = 'mean')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>WeeklyWages</th>
    </tr>
    <tr>
      <th>Department</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Engineering</th>
      <td>1542.064500</td>
    </tr>
    <tr>
      <th>Marketing</th>
      <td>643.081000</td>
    </tr>
    <tr>
      <th>Production</th>
      <td>534.797486</td>
    </tr>
  </tbody>
</table>
</div>




```python
# What are the totals of weekly wages of male and female employees across departments using Pivot_table()?

wage.pivot_table(index = 'Department', columns = 'Sex', values = 'WeeklyWages', aggfunc = 'sum')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Sex</th>
      <th>Female</th>
      <th>Male</th>
    </tr>
    <tr>
      <th>Department</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Document Control</th>
      <td>NaN</td>
      <td>2962.030</td>
    </tr>
    <tr>
      <th>Engineering</th>
      <td>2475.018</td>
      <td>6777.369</td>
    </tr>
    <tr>
      <th>Executive</th>
      <td>NaN</td>
      <td>9025.200</td>
    </tr>
    <tr>
      <th>Facilities and Maintenance</th>
      <td>693.750</td>
      <td>2901.113</td>
    </tr>
    <tr>
      <th>Finance</th>
      <td>2629.029</td>
      <td>6837.132</td>
    </tr>
    <tr>
      <th>Human Resources</th>
      <td>1909.796</td>
      <td>1940.836</td>
    </tr>
    <tr>
      <th>Information Services</th>
      <td>1850.488</td>
      <td>9536.135</td>
    </tr>
    <tr>
      <th>Marketing</th>
      <td>1490.398</td>
      <td>4940.412</td>
    </tr>
    <tr>
      <th>Production</th>
      <td>16622.200</td>
      <td>79106.550</td>
    </tr>
    <tr>
      <th>Production Control</th>
      <td>NaN</td>
      <td>4940.252</td>
    </tr>
    <tr>
      <th>Purchasing</th>
      <td>4406.991</td>
      <td>5840.741</td>
    </tr>
    <tr>
      <th>Quality Assurance</th>
      <td>465.388</td>
      <td>3177.900</td>
    </tr>
    <tr>
      <th>Research and Development</th>
      <td>1593.735</td>
      <td>5172.675</td>
    </tr>
    <tr>
      <th>Sales</th>
      <td>1823.083</td>
      <td>18439.207</td>
    </tr>
    <tr>
      <th>Shipping and Receiving</th>
      <td>692.316</td>
      <td>1698.500</td>
    </tr>
    <tr>
      <th>Tool Design</th>
      <td>NaN</td>
      <td>5304.752</td>
    </tr>
  </tbody>
</table>
</div>



# Matplotlib


```python
# How are mean wages different between females and males?  

mean_wages = wage['WeeklyWages'].groupby(wage['Sex']).mean()
x1 = mean_wages.index
y1 = mean_wages.values
plt.bar(x1, y1, align = 'center', color = 'red')
```




    <BarContainer object of 2 artists>




![png](output_16_1.png)



```python
# How are mean wages different between departments?  

mean_wages = wage['WeeklyWages'].groupby(wage['Department']).mean()
x1 = mean_wages.index
y1 = mean_wages.values
plt.barh(x1,y1, align = 'center', color = 'red')
```




    <BarContainer object of 16 artists>




![png](output_17_1.png)



```python

```
